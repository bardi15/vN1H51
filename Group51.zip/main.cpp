//#include <QCoreApplication>
#include <iostream>
#include "scientist.h"
#include "infodisplay.h"
#include "workingclass.h"

using namespace std;

int main()
{    
//    infoDisplay display;

    service service;
    service.selectAction();
    return 0;
}
